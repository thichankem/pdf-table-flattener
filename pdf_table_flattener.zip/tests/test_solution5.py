import pytest
from src.pdf_table_tool.cell_normalizer import CellNormalizer
from src.pdf_table_tool.context_stack import ContextStack, StackFrame, Cell
from src.pdf_table_tool.merged_cell_recovery import MergedCellRecoveryEngine

def test_cell_normalizer_unicode_nfc():
    raw_text = "３.１\tĐiều  kiện   vay vốn\xa0"
    normalized = CellNormalizer.normalize_text(raw_text)
    assert normalized == "3.1 Điều kiện vay vốn"

def test_cell_normalizer_circled_bullets():
    raw_text = "① Căn cước công dân"
    normalized = CellNormalizer.normalize_text(raw_text)
    assert normalized == "1. Căn cước công dân"

def test_context_stack_hierarchy():
    stack = ContextStack()
    stack.update(level=1, numbering="3", title="Điều kiện chung", col_idx=0)
    stack.update(level=2, numbering="3.1", title="Điều kiện vay vốn", col_idx=1)
    
    path = stack.get_full_path(["Khoản", "Điều kiện"])
    assert len(path) == 2
    assert "Khoản: 3 - Điều kiện chung" in path[0]
    assert "Điều kiện: 3.1 - Điều kiện vay vốn" in path[1]

    # Pop level 2 when a new level 2 item arrives
    stack.update(level=2, numbering="3.2", title="Hồ sơ pháp lý", col_idx=1)
    new_path = stack.get_full_path(["Khoản", "Điều kiện"])
    assert len(new_path) == 2
    assert "3.2 - Hồ sơ pháp lý" in new_path[1]

def test_continuation_page2_bullet_alignment():
    from src.pdf_table_tool.row_context import RowContextPropagator, RowContext
    from src.pdf_table_tool.formatter import TableFormatter
    from src.pdf_table_tool.extractors.base import TableData

    # Simulate Page 1 Active RowContext
    active_row_ctx = RowContext(
        row_id="3.1",
        title="Điều kiện vay vốn",
        level=2,
        path=["Khoản: 3.1", "Điều kiện: Điều kiện vay vốn"]
    )

    # Page 2 extracted continuation rows (1-column extracted bullet items)
    page2_raw_rows = [
        ["+ Căn cước công dân gắn chíp điện tử của Khách hàng; hoặc:"],
        ["+ Giấy xác nhận thông tin về cư trú do công an xã/phường/thị"],
        ["+ Thông báo kết quả giải quyết thủ tục về đăng ký cư trú"]
    ]

    expected_cols = 3
    # Step 1: Align single-cell rows to Col 2 (Quy định)
    aligned_rows = MergedCellRecoveryEngine.recover_table_rows(page2_raw_rows, expected_cols)
    assert aligned_rows[0][2] == "+ Căn cước công dân gắn chíp điện tử của Khách hàng; hoặc:"

    # Step 2: Apply Active Row Context (fills Col 0: "3.1" and Col 1: "Điều kiện vay vốn")
    contextualized_rows = RowContextPropagator.apply_context_to_rows(aligned_rows, active_row_ctx, expected_cols)
    assert contextualized_rows[0][0] == "3.1"
    assert contextualized_rows[0][1] == "Điều kiện vay vốn"

    # Step 2.5: Merge cell continuation rows into unified logical row
    from src.pdf_table_tool.cell_continuation import CellContinuationEngine
    merged_rows = CellContinuationEngine.merge_continuation_rows(contextualized_rows, expected_cols)
    assert len(merged_rows) == 1

    # Step 3: Format to bullets with AST hierarchy
    t_data = TableData(headers=["Khoản", "Điều kiện", "Quy định"], rows=merged_rows)
    bullets = TableFormatter.format_to_bullets(t_data)
    
    assert len(bullets) == 4
    assert bullets[0] == "- Khoản: 3.1  |  Điều kiện: Điều kiện vay vốn"
    assert "    + Căn cước công dân gắn chíp" in bullets[1]

def test_continuation_top_content_preservation():
    from src.pdf_table_tool.extractors.rule_extractor import RuleExtractor

    rule_ext = RuleExtractor()

    # Simulate raw extracted table rows on Page 2 where Row 0 is a top bullet item
    page2_rows = [
        ["- Không có nợ nhóm 2, không có thẻ tín dụng chậm trả..."],
        ["Đối với trường hợp tra CIC mà Khách hàng phát sinh nợ nhóm 2..."],
        ["+ Căn cước công dân gắn chíp điện tử của Khách hàng; hoặc:"]
    ]

    headers, data_rows = rule_ext._parse_headers_and_rows(page2_rows)
    # Ensure Row 0 was NOT mistaken for a header and discarded!
    assert headers == []
    assert len(data_rows) == 3
    assert data_rows[0][0].startswith("- Không có nợ nhóm 2")

def test_cell_continuation_engine():
    from src.pdf_table_tool.cell_continuation import CellContinuationEngine
    from src.pdf_table_tool.formatter import TableFormatter
    from src.pdf_table_tool.extractors.base import TableData

    rows = [
        ["3.1", "Điều kiện vay vốn", "- Không có nợ nhóm 2..."],
        ["3.1", "Điều kiện vay vốn", "+ Căn cước công dân gắn chíp..."],
        ["3.1", "Điều kiện vay vốn", "+ Giấy xác nhận cư trú..."]
    ]

    merged = CellContinuationEngine.merge_continuation_rows(rows, expected_cols=3)
    assert len(merged) == 1
    assert "Không có nợ nhóm 2" in merged[0][2]
    assert "+ Căn cước công dân" in merged[0][2]

    # Format to bullets
    t_data = TableData(headers=["Khoản", "Điều kiện", "Quy định"], rows=merged)
    bullets = TableFormatter.format_to_bullets(t_data)
    assert len(bullets) == 4
    assert bullets[0] == "- Khoản: 3.1  |  Điều kiện: Điều kiện vay vốn"
    assert "  - Không có nợ nhóm 2..." in bullets[1]
    assert "    + Căn cước công dân gắn chíp..." in bullets[2]
