import pytest
import pdfplumber
import fitz
from pathlib import Path
from src.pdf_table_tool.formatter import TableFormatter
from src.pdf_table_tool.extractors.base import TableData
from src.pdf_table_tool.pipeline import PDFTableFlattenerPipeline

TEST_PDF_DIR = Path(__file__).parent.parent / "input test"

def test_formatter_criteria_2_and_3():
    """Verify criteria 2 & 3: bullet format and clean output without fake labels."""
    sample_table = TableData(
        headers=["Tên", "Tuổi", "Chức vụ", "Cột 4"],
        rows=[
            ["Nam", "25", "Dev", "Ghi chú 1"],
            ["Hoa", "23", "Designer", ""],
        ]
    )

    bullets = TableFormatter.format_to_bullets(sample_table)

    assert len(bullets) == 2
    assert bullets[0] == "- Tên: Nam  |  Tuổi: 25  |  Chức vụ: Dev  |  Ghi chú 1"
    # Verify 'Cột 4' fake header filtering: empty cell skipped, value appended clean
    assert bullets[1] == "- Tên: Hoa  |  Tuổi: 23  |  Chức vụ: Designer"

def test_formatter_numeric_headers():
    """Verify that numeric headers like '10', '15', '20', '25' are NOT dropped even if values end with '%'."""
    table_data = TableData(
        headers=["Năm hợp đồng", "10", "15", "20", "25"],
        rows=[
            ["1", "0%", "0%", "0%", "0%"],
            ["3", "10%", "10%", "5%", "5%"],
            ["11", "", "50%", "40%", "25%"],
        ]
    )

    bullets = TableFormatter.format_to_bullets(table_data)

    assert bullets[0] == "- Năm hợp đồng: 1  |  10: 0%  |  15: 0%  |  20: 0%  |  25: 0%"
    assert bullets[1] == "- Năm hợp đồng: 3  |  10: 10%  |  15: 10%  |  20: 5%  |  25: 5%"
    assert bullets[2] == "- Năm hợp đồng: 11  |  15: 50%  |  20: 40%  |  25: 25%"

def test_formatter_transposed_col0_metric():
    """Verify 2-row table where col 0 is metric label containing header word."""
    table_data = TableData(
        headers=["Năm hợp đồng", "Năm 1", "Năm 2", "Năm 3 trở đi"],
        rows=[
            ["% Phí bảo hiểm đã đóng tại từng Năm hợp đồng", "90%", "10%", "5%"]
        ]
    )

    bullets = TableFormatter.format_to_bullets(table_data)
    assert bullets[0] == "- % Phí bảo hiểm đã đóng tại từng Năm hợp đồng  |  Năm 1: 90%  |  Năm 2: 10%  |  Năm 3 trở đi: 5%"

def test_rule_extractor_rowspan_deduplication():
    """Verify RuleExtractor deduplicates vertical merged cells correctly."""
    from src.pdf_table_tool.extractors.rule_extractor import RuleExtractor

    extractor = RuleExtractor()
    long_text = "Không phát sinh nợ từ nhóm 2 trở lên và không có thẻ tín dụng chậm trả từ 10 ngày trở lên tại Ngân hàng..."
    rows = [
        ["3.3", "Điều kiện", long_text],
        ["3.4", "Phân nhóm", long_text],
        ["3.5", "Hạn mức", long_text],
    ]
    deduped = extractor._deduplicate_vertical_spans(rows)
    assert deduped[0][2] == long_text
    assert deduped[1][2] == ""
    assert deduped[2][2] == ""

def test_bullet_header_skip_protection():
    """Verify that headers starting with bullet symbols (+, -, *) are skipped as header prefixes."""
    table_data = TableData(
        headers=["+ Căn cước công dân gắn chip điện tử", "Quy định"],
        rows=[
            ["+ Giấy xác nhận thông tin cư trú", "Thỏa mãn"],
        ]
    )
    bullets = TableFormatter.format_to_bullets(table_data)
    # The header starting with '+ ' must NOT be prepended as a header prefix
    assert not any("Căn cước công dân gắn chip điện tử:" in b for b in bullets)

def test_merged_cell_recovery():
    """Verify MergedCellRecoveryEngine correctly fills down Col 0 and Col 1 values."""
    from src.pdf_table_tool.merged_cell_recovery import MergedCellRecoveryEngine

    raw_rows = [
        ["3.1", "Điều kiện vay vốn", "+ Khách hàng là Chủ hộ kinh doanh"],
        ["", "", "+ Đủ 18 tuổi trở lên"],
    ]
    recovered = MergedCellRecoveryEngine.recover_table_rows(raw_rows, expected_num_cols=3)
    assert recovered[0] == ["3.1", "Điều kiện vay vốn", "+ Khách hàng là Chủ hộ kinh doanh"]
    assert recovered[1] == ["3.1", "Điều kiện vay vốn", "+ Đủ 18 tuổi trở lên"]

def test_row_context_propagation():
    """Verify RowContextPropagator applies active context across page breaks."""
    from src.pdf_table_tool.row_context import RowContextPropagator, RowContext

    headers = ["Khoản", "Điều kiện", "Quy định"]
    last_row = ["3.1", "Điều kiện vay vốn", "+ Khách hàng là Chủ hộ kinh doanh"]
    active_ctx = RowContextPropagator.extract_active_context(headers, last_row)

    assert active_ctx.row_id == "3.1"
    assert active_ctx.title == "Điều kiện vay vốn"

    page2_rows = [
        ["", "", "+ Không có nợ nhóm 2"],
        ["", "", "+ Có địa điểm kinh doanh"],
    ]
    updated = RowContextPropagator.apply_context_to_rows(page2_rows, active_ctx, expected_cols=3)
    assert updated[0][0] == "3.1"
    assert updated[0][1] == "Điều kiện vay vốn"
    assert updated[1][0] == "3.1"
    assert updated[1][1] == "Điều kiện vay vốn"



