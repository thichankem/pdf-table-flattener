import pytest
from src.pdf_table_tool.table_detector import TableInfo, link_multipage_tables
from src.pdf_table_tool.cell_continuation import CellContinuationEngine
from src.pdf_table_tool.row_context import RowContextPropagator, RowContext
from src.pdf_table_tool.formatter import TableFormatter
from src.pdf_table_tool.extractors.base import TableData

def test_level1_open_border_top_bbox_extension():
    class DummyPage:
        height = 792.0
    class DummyPDF:
        pages = [DummyPage(), DummyPage()]

    # Simulate first table on Page 2 with top y=120
    t1 = TableInfo(page_num=0, bbox=(30, 200, 550, 750))
    t2 = TableInfo(page_num=1, bbox=(30, 120, 550, 600))

    pages = {0: [t1], 1: [t2]}
    # Link multipage
    linked = link_multipage_tables(DummyPDF(), pages)
    t2_linked = linked[1][0]

    assert t2_linked.is_continuation is True
    # Ensure top bbox extended to top margin (y <= 35)
    assert t2_linked.bbox[1] <= 60.0

def test_level2_logical_cell_continuation():
    rows = [
        ["3.1", "Điều kiện vay vốn", "- Khách hàng là Chủ hộ..."],
        ["3.1", "Điều kiện vay vốn", "- Không có nợ nhóm 2..."],
        ["3.1", "Điều kiện vay vốn", "+ Căn cước công dân..."]
    ]

    merged = CellContinuationEngine.merge_continuation_rows(rows, expected_cols=3)
    assert len(merged) == 1
    assert "Khách hàng là Chủ hộ" in merged[0][2]
    assert "Không có nợ nhóm 2" in merged[0][2]
    assert "+ Căn cước công dân" in merged[0][2]

def test_level3_semantic_ast_formatting():
    rows = [
        ["3.1", "Điều kiện vay vốn", "- Khách hàng là Chủ hộ...\n- Đủ 18 tuổi...\n+ Căn cước công dân..."]
    ]
    t_data = TableData(headers=["Khoản", "Điều kiện", "Quy định"], rows=rows)
    bullets = TableFormatter.format_to_bullets(t_data)

    assert len(bullets) == 4
    assert bullets[0] == "- Khoản: 3.1  |  Điều kiện: Điều kiện vay vốn"
    assert bullets[1].startswith("  - Khách hàng")
    assert bullets[2].startswith("  - Đủ 18 tuổi")
    assert bullets[3].startswith("    + Căn cước công dân")
