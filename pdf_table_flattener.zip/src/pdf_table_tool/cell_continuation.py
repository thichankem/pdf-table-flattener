import re
from typing import List, Dict, Any, Tuple
import logging

logger = logging.getLogger(__name__)

class CellContinuationEngine:
    """
    Engine responsible for detecting cell continuation across rows and pages.
    Merges consecutive rows sharing identical row_id (Col 0) and title (Col 1)
    into a unified Logical Row with a rich cell text buffer, preserving nested bullet hierarchy.
    """

    @staticmethod
    def merge_continuation_rows(rows: List[List[str]], expected_cols: int = 3) -> List[List[str]]:
        if not rows:
            return []

        merged_rows: List[List[str]] = []
        current_logical_row: List[str] = []

        for row in rows:
            # Ensure row has expected_cols
            if len(row) < expected_cols:
                padded = [""] * expected_cols
                for idx, c in enumerate(row):
                    padded[idx if idx < expected_cols else expected_cols - 1] = c
                row = padded

            col0 = row[0].strip()
            col1 = row[1].strip() if expected_cols > 1 else ""
            col2 = row[expected_cols - 1].strip() if expected_cols > 2 else ""

            if not current_logical_row:
                current_logical_row = list(row)
                continue

            curr_col0 = current_logical_row[0].strip()
            curr_col1 = current_logical_row[1].strip() if expected_cols > 1 else ""

            # Check if this row is a continuation of the current logical row
            is_same_context = (col0 == curr_col0) and (col1 == curr_col1 or not col1)
            is_empty_headers = not col0 and not col1

            if is_same_context or is_empty_headers:
                # Merge col2 text into current_logical_row's rightmost cell
                if col2:
                    existing_text = current_logical_row[expected_cols - 1]
                    if existing_text:
                        current_logical_row[expected_cols - 1] = existing_text + "\n" + col2
                    else:
                        current_logical_row[expected_cols - 1] = col2
            else:
                merged_rows.append(current_logical_row)
                current_logical_row = list(row)

        if current_logical_row:
            merged_rows.append(current_logical_row)

        logger.info(f"CellContinuationEngine: Merged {len(rows)} raw rows into {len(merged_rows)} logical rows.")
        return merged_rows
