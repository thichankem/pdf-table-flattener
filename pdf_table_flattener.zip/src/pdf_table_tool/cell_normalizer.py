import unicodedata
import re

class CellNormalizer:
    """
    Normalization layer for PDF table cells.
    Executes unicode normalization, full-width conversion, whitespace cleaning,
    and bullet standardization BEFORE any repair or context processing.
    """

    @staticmethod
    def normalize_text(text: str) -> str:
        if not text:
            return ""

        # Step 1: Unicode NFC Normalization
        text = unicodedata.normalize("NFC", text)

        # Step 2: Convert Full-Width characters to ASCII / Half-Width
        text = CellNormalizer._fullwidth_to_halfwidth(text)

        # Step 3: Replace non-breaking space, tabs, carriage returns
        text = text.replace("\xa0", " ").replace("\r\n", "\n").replace("\r", "\n").replace("\t", " ")

        # Step 4: Collapse multiple spaces per line
        lines = text.split("\n")
        cleaned_lines = [re.sub(r" {2,}", " ", line).strip() for line in lines]
        text = "\n".join(line for line in cleaned_lines if line)

        # Step 5: Standardize bullet symbols
        text = CellNormalizer._standardize_bullets(text)

        return text.strip()

    @staticmethod
    def _fullwidth_to_halfwidth(text: str) -> str:
        """Converts full-width Unicode characters to standard half-width ASCII."""
        result = []
        for char in text:
            code = ord(char)
            # Full-width ASCII range 0xFF01 to 0xFF5E maps to 0x21 to 0x7E (offset 0xFEE0)
            if 0xFF01 <= code <= 0xFF5E:
                result.append(chr(code - 0xFEE0))
            # Full-width space 0x3000 -> 0x0020
            elif code == 0x3000:
                result.append(" ")
            else:
                result.append(char)
        return "".join(result)

    @staticmethod
    def _standardize_bullets(text: str) -> str:
        """Standardize circled numbers (①, ②) or varied bullet characters into uniform bullet formatting."""
        # Convert circled numbers ①..⑩ to 1..10 if present as standalone bullet items
        circled_map = {
            "①": "1.", "②": "2.", "③": "3.", "④": "4.", "⑤": "5.",
            "⑥": "6.", "⑦": "7.", "⑧": "8.", "⑨": "9.", "⑩": "10."
        }
        for circled, replacement in circled_map.items():
            if text.startswith(circled):
                text = replacement + " " + text[len(circled):].lstrip()

        return text
