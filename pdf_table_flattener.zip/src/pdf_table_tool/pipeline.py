import os
from typing import Dict, List, Any
from .table_detector import detect_tables_by_page
from .router import TableRouter
from .formatter import TableFormatter
from .layout_planner import LayoutPlanner
from .pdf_patcher import PDFPatcher
from .ollama_bootstrap import ensure_ollama_running
import logging

from .merged_cell_recovery import MergedCellRecoveryEngine
from .row_context import RowContextPropagator, RowContext

logger = logging.getLogger(__name__)

class PDFTableFlattenerPipeline:
    def __init__(self, check_ollama: bool = True):
        self.check_ollama = check_ollama
        self.router = TableRouter()
        self.formatter = TableFormatter()
        self.planner = LayoutPlanner()
        self.patcher = PDFPatcher()

    def process(self, pdf_path: str, output_path: str) -> Dict[str, Any]:
        """
        Main end-to-end pipeline execution with Merged Cell Recovery & RowContext Propagation.
        """
        logger.info(f"Starting processing for file: {pdf_path}")
        if self.check_ollama:
            is_ollama_ok, msg = ensure_ollama_running()
            logger.info(f"Ollama status: {msg}")

        # Step 1: Detect tables & classify pages
        pages_with_tables, pages_without_tables = detect_tables_by_page(pdf_path)

        patches_by_page: Dict[int, List[Dict[str, Any]]] = {}
        total_tables_processed = 0

        # Store extraction context per page for continuation linking
        last_page_context: Dict[int, Dict[str, Any]] = {}

        # Step 2: Route, extract, recover merged cells, format & plan layout for pages with tables
        for page_num in sorted(pages_with_tables.keys()):
            tables = pages_with_tables[page_num]
            page_patches = []
            for t_info in tables:
                bbox = t_info.bbox
                # Route & Extract table data
                table_data = self.router.route_and_extract(pdf_path, page_num, bbox)

                # Check if this table is a multi-page continuation table
                active_row_ctx = None
                if t_info.is_continuation and t_info.parent_page_num in last_page_context:
                    parent_ctx = last_page_context[t_info.parent_page_num]
                    parent_headers = parent_ctx.get("headers", [])
                    active_row_ctx = parent_ctx.get("active_row_context")

                    if parent_headers:
                        logger.info(
                            f"Page {page_num + 1}: Inheriting headers from Page {t_info.parent_page_num + 1} "
                            f"for continuation table ({parent_headers})"
                        )
                        # Treat previous 'headers' row if mistaken for headers as data row
                        all_rows = []
                        if table_data.headers and table_data.headers != parent_headers:
                            all_rows.append(table_data.headers)
                        all_rows.extend(table_data.rows or [])

                        table_data.headers = parent_headers
                        table_data.rows = all_rows
                        table_data.is_continuation = True

                # Step 5 & 6 (Solution 5.0): Merged Cell Recovery, Cell Continuation & Context Propagation
                expected_cols = len(table_data.headers) if table_data.headers else 3

                # 1. Merged Cell Recovery Engine: Normalize cells, align single-cell rows to Col 2 (Quy định), fill-down
                if table_data.rows:
                    table_data.rows = MergedCellRecoveryEngine.recover_table_rows(
                        table_data.rows, expected_cols
                    )

                # 2. Cell Continuation Engine: Merge consecutive rows sharing identical context into unified Logical Rows
                if table_data.rows:
                    from .cell_continuation import CellContinuationEngine
                    table_data.rows = CellContinuationEngine.merge_continuation_rows(
                        table_data.rows, expected_cols
                    )

                # 3. Propagate Active Row Context (fill Col 0 & Col 1 with inherited row_id / title across continuation rows)
                if active_row_ctx and table_data.rows:
                    table_data.rows = RowContextPropagator.apply_context_to_rows(
                        table_data.rows, active_row_ctx, expected_cols
                    )

                # Format table data to clean bullets
                bullet_lines = self.formatter.format_to_bullets(table_data)

                # Plan layout
                layout_info = self.planner.plan_layout(bbox, bullet_lines)

                page_patches.append({
                    "table_data": table_data,
                    "bullet_lines": bullet_lines,
                    "layout": layout_info,
                    "original_bbox": bbox
                })
                total_tables_processed += 1

                # Extract and save active RowContext for potential continuation on next page
                last_row = table_data.rows[-1] if table_data.rows else []
                new_active_ctx = RowContextPropagator.extract_active_context(table_data.headers, last_row)

                last_page_context[page_num] = {
                    "headers": table_data.headers,
                    "last_row": last_row,
                    "active_row_context": new_active_ctx
                }

            patches_by_page[page_num] = page_patches

        # Step 3: Patch PDF
        self.patcher.process_pdf(
            pdf_path=pdf_path,
            output_path=output_path,
            patches_by_page=patches_by_page,
            pages_without_tables=pages_without_tables
        )

        summary = {
            "input_file": pdf_path,
            "output_file": output_path,
            "pages_passthrough_count": len(pages_without_tables),
            "pages_patched_count": len(pages_with_tables),
            "total_tables_flattened": total_tables_processed,
            "status": "success"
        }
        logger.info(f"Processing complete: {summary}")
        return summary
