import re
from typing import Dict, List, Set, Tuple, Any
import pdfplumber
import fitz  # PyMuPDF
import logging

logger = logging.getLogger(__name__)

class TableInfo:
    def __init__(
        self,
        page_num: int,
        bbox: Tuple[float, float, float, float],
        raw_table: Any = None,
        is_continuation: bool = False,
        parent_page_num: int = -1
    ):
        self.page_num = page_num
        self.bbox = bbox  # (x0, top, x1, bottom)
        self.raw_table = raw_table
        self.is_continuation = is_continuation
        self.parent_page_num = parent_page_num

def detect_tables_by_page(pdf_path: str) -> Tuple[Dict[int, List[TableInfo]], Set[int]]:
    """
    Detect tables page-by-page in PDF and link multi-page continuations.
    Returns:
        pages_with_tables: Dict[page_num -> List[TableInfo]]
        pages_without_tables: Set[page_num]
    """
    pages_with_tables: Dict[int, List[TableInfo]] = {}
    pages_without_tables: Set[int] = set()

    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages):
            p_height = float(page.height)
            table_objs = page.find_tables()
            valid_tables = []

            for t in table_objs:
                x0, top, x1, bottom = t.bbox
                width = x1 - x0
                height = bottom - top
                if width > 20 and height > 15:
                    valid_tables.append(TableInfo(page_num=page_num, bbox=t.bbox, raw_table=t))

            if valid_tables:
                merged_tables = merge_table_infos(page_num, valid_tables)
                pages_with_tables[page_num] = merged_tables
            else:
                pages_without_tables.add(page_num)

        # Link multi-page tables across consecutive pages
        pages_with_tables = link_multipage_tables(pdf, pages_with_tables)

    logger.info(
        f"Table Detection complete: {len(pages_with_tables)} pages with tables, "
        f"{len(pages_without_tables)} pages without tables (passthrough)."
    )
    return pages_with_tables, pages_without_tables

def compute_text_similarity(last_table: TableInfo, first_table: TableInfo) -> float:
    """Computes Jaccard text similarity between extracted text snippets of two table candidates."""
    try:
        raw_last = last_table.raw_table.extract() if last_table.raw_table else []
        raw_first = first_table.raw_table.extract() if first_table.raw_table else []

        if not raw_last or not raw_first:
            return 0.5  # Neutral fallback if extraction is unavailable

        str_last = " ".join([c for row in raw_last[-2:] for c in row if c]).lower()
        str_first = " ".join([c for row in raw_first[:2] for c in row if c]).lower()

        tokens_last = set(re.findall(r"\w+", str_last))
        tokens_first = set(re.findall(r"\w+", str_first))

        if not tokens_last or not tokens_first:
            return 0.5

        intersection = tokens_last.intersection(tokens_first)
        union = tokens_last.union(tokens_first)
        return len(intersection) / float(len(union))
    except Exception:
        return 0.5

def compute_continuation_score(last_table: TableInfo, first_table: TableInfo, curr_h: float, next_h: float) -> float:
    """
    Computes weighted continuation score between two candidate tables on consecutive pages.
    Score = 0.30 * spatial + 0.30 * col_align + 0.20 * text_similarity + 0.20 * width_similarity
    """
    # 1. Spatial proximity score
    spatial_score = 0.0
    if last_table.bbox[3] > (curr_h * 0.50) and first_table.bbox[1] < (next_h * 0.45):
        spatial_score = 1.0
    elif last_table.bbox[3] > (curr_h * 0.40) and first_table.bbox[1] < (next_h * 0.50):
        spatial_score = 0.70

    # 2. Column alignment score (X0 difference)
    x0_diff = abs(last_table.bbox[0] - first_table.bbox[0])
    align_score = max(0.0, 1.0 - (x0_diff / 40.0))

    # 3. Text similarity score (Jaccard)
    text_sim_score = compute_text_similarity(last_table, first_table)

    # 4. Width similarity score
    w_last = last_table.bbox[2] - last_table.bbox[0]
    w_first = first_table.bbox[2] - first_table.bbox[0]
    width_diff = abs(w_last - w_first)
    width_score = max(0.0, 1.0 - (width_diff / 50.0))

    final_score = (0.30 * spatial_score) + (0.30 * align_score) + (0.20 * text_sim_score) + (0.20 * width_score)
    return final_score

from dataclasses import dataclass

@dataclass
class ContinuationEvidence:
    same_column_geometry: bool
    same_table_width: bool
    previous_table_touches_page_bottom: bool
    current_table_starts_near_content_top: bool
    repeated_header_detected: bool
    left_boundary_match: bool
    right_boundary_match: bool
    score: float

    def is_valid(self) -> bool:
        return self.same_column_geometry and self.score >= 0.55

def link_multipage_tables(pdf: pdfplumber.PDF, pages_with_tables: Dict[int, List[TableInfo]]) -> Dict[int, List[TableInfo]]:
    """
    Identifies continuation tables across consecutive pages using a weighted score & Hard Constraints.
    If Continuation Score >= 0.55 & same column geometry, mark Page N+1 table as is_continuation = True.
    """
    sorted_pages = sorted(pages_with_tables.keys())
    for i in range(len(sorted_pages) - 1):
        curr_page = sorted_pages[i]
        next_page = sorted_pages[i + 1]

        # Must be consecutive pages
        if next_page != curr_page + 1:
            continue

        curr_tables = pages_with_tables[curr_page]
        next_tables = pages_with_tables[next_page]

        if not curr_tables or not next_tables:
            continue

        # Last table on current page
        last_table = max(curr_tables, key=lambda t: t.bbox[3])
        # First table on next page
        first_table = min(next_tables, key=lambda t: t.bbox[1])

        p_curr = pdf.pages[curr_page] if pdf else None
        p_next = pdf.pages[next_page] if pdf else None

        curr_h = float(p_curr.height) if p_curr else 792.0
        next_h = float(p_next.height) if p_next else 792.0

        score = compute_continuation_score(last_table, first_table, curr_h, next_h)

        # Hard constraints
        x0_diff = abs(last_table.bbox[0] - first_table.bbox[0])
        same_col_geom = (x0_diff <= 30.0)

        evidence = ContinuationEvidence(
            same_column_geometry=same_col_geom,
            same_table_width=abs((last_table.bbox[2]-last_table.bbox[0]) - (first_table.bbox[2]-first_table.bbox[0])) <= 40.0,
            previous_table_touches_page_bottom=last_table.bbox[3] > (curr_h * 0.40),
            current_table_starts_near_content_top=first_table.bbox[1] < (next_h * 0.50),
            repeated_header_detected=False,
            left_boundary_match=same_col_geom,
            right_boundary_match=same_col_geom,
            score=score
        )

        if evidence.is_valid():
            first_table.is_continuation = True
            first_table.parent_page_num = curr_page
            # Extend top bbox coordinate safely (header_exclusion_bottom = 45.0)
            orig_top = first_table.bbox[1]
            header_exclusion_bottom = 45.0
            safe_top = max(orig_top - 60.0, header_exclusion_bottom)
            safe_top = min(safe_top, orig_top)  # Enforce safe_top <= orig_top

            first_table.bbox = (first_table.bbox[0], safe_top, first_table.bbox[2], first_table.bbox[3])
            logger.info(
                f"Multi-Page Table Linker: Page {next_page + 1} table linked to Page {curr_page + 1} "
                f"(Evidence Score: {evidence.score:.2f}, safe_top: {orig_top:.1f} -> {safe_top:.1f})."
            )

    return pages_with_tables

def merge_table_infos(page_num: int, tables: List[TableInfo], margin: float = 10.0) -> List[TableInfo]:
    """Merge table bboxes on the same page that overlap or lie within `margin` distance."""
    if not tables:
        return []

    boxes = [t.bbox for t in tables]
    merged_boxes = []

    for box in sorted(boxes, key=lambda b: (b[1], b[0])):
        if not merged_boxes:
            merged_boxes.append(box)
        else:
            prev = merged_boxes[-1]
            # Check overlap or close proximity
            if (box[1] <= prev[3] + margin) and (box[0] <= prev[2] + margin) and (box[2] >= prev[0] - margin):
                # Merge
                new_box = (
                    min(prev[0], box[0]),
                    min(prev[1], box[1]),
                    max(prev[2], box[2]),
                    max(prev[3], box[3])
                )
                merged_boxes[-1] = new_box
            else:
                merged_boxes.append(box)

    return [TableInfo(page_num=page_num, bbox=b) for b in merged_boxes]
