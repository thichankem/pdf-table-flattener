import re
from typing import List, Tuple, Dict, Any
import logging
from .cell_normalizer import CellNormalizer
from .context_stack import Cell

logger = logging.getLogger(__name__)

class MergedCellRecoveryEngine:
    """
    Engine responsible for normalizing cells, detecting horizontal merged section rows (colspan),
    recovering vertical missing merged cells (fill-down / rowspan), and ensuring complete row data.
    """

    @staticmethod
    def recover_table_rows(rows: List[List[str]], expected_num_cols: int = -1) -> List[List[str]]:
        if not rows:
            return []

        if expected_num_cols <= 0:
            expected_num_cols = max(len(r) for r in rows)

        # Step 1: Cell Normalization (Unicode NFC, full-width, whitespace, bullets)
        normalized_rows = []
        for row in rows:
            norm_r = [CellNormalizer.normalize_text(cell) for cell in row]
            normalized_rows.append(norm_r)

        # Step 2: Align row column count to match expected_num_cols
        aligned_rows = []
        for r in normalized_rows:
            aligned_r = MergedCellRecoveryEngine._align_row(r, expected_num_cols)
            aligned_rows.append(aligned_r)

        # Step 3: Fill-down vertical merged cells for Col 0 and Col 1
        recovered_rows = MergedCellRecoveryEngine._fill_down(aligned_rows, expected_num_cols)

        return recovered_rows

    @staticmethod
    def _align_row(row: List[str], expected_cols: int) -> List[str]:
        """Ensures row has exact length expected_cols and correctly handles section headers vs bullet items."""
        if not row:
            return [""] * expected_cols

        # Check for Single-Cell Row (only 1 cell with content)
        non_empty = [c for c in row if c.strip()]
        if len(non_empty) == 1 and expected_cols > 1:
            val = non_empty[0].strip()
            is_bullet = bool(re.match(r"^[\+\-\*\•]\s", val) or val.startswith("+ ") or val.startswith("- ") or val.startswith("("))
            is_section_hdr = bool(re.match(r"^(\d+(\.\d+)*|[A-ZIVX]+\.|\bMỤC\b|\bPHẦN\b)", val, re.IGNORECASE))

            if is_section_hdr and not is_bullet:
                padded = [""] * expected_cols
                padded[0] = val
                return padded
            else:
                # Bullet items or general continuation text belong in the last data column (Quy định)
                padded = [""] * expected_cols
                padded[-1] = val
                return padded

        if len(row) == expected_cols:
            return list(row)

        if len(row) < expected_cols:
            # If row has fewer elements (e.g. 1 cell containing bullet points),
            # place it in the rightmost data column (index expected_cols - 1)
            padded = [""] * expected_cols
            val = row[0] if row else ""
            padded[-1] = val
            return padded
        else:
            # If row has more elements, merge overflow into rightmost cell
            padded = list(row[:expected_cols - 1])
            overflow = " ".join(c for c in row[expected_cols - 1:] if c)
            padded.append(overflow)
            return padded

    @staticmethod
    def _fill_down(rows: List[List[str]], expected_cols: int) -> List[List[str]]:
        """
        Fills down values for Col 0 and Col 1 across consecutive rows if empty.
        """
        recovered = [list(r) for r in rows]
        active_context = [""] * expected_cols

        for r_idx in range(len(recovered)):
            row = recovered[r_idx]

            # Update active context for non-empty cells that are NOT bullet list items
            for c_idx in range(min(2, expected_cols)):
                cell_val = row[c_idx].strip()
                if cell_val and not re.match(r"^[\+\-\*\•]\s", cell_val):
                    active_context[c_idx] = cell_val
                elif not cell_val and active_context[c_idx]:
                    # Fill down from active context
                    row[c_idx] = active_context[c_idx]

        return recovered

