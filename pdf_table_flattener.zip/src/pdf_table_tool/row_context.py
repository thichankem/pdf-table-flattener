import re
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import logging
from .context_stack import ContextStack, StackFrame

logger = logging.getLogger(__name__)

@dataclass
class RowContext:
    row_id: str = ""
    title: str = ""
    level: int = 1
    path: List[str] = field(default_factory=list)
    stack: Optional[ContextStack] = None

    def is_empty(self) -> bool:
        return not self.row_id and not self.title and (self.stack is None or self.stack.is_empty())

class RowContextPropagator:
    """
    Manages active RowContext and ContextStack propagation across pages and merged cell boundaries.
    """

    @staticmethod
    def extract_active_context(headers: List[str], last_row: List[str]) -> Optional[RowContext]:
        if not last_row:
            return None

        col0 = last_row[0].strip() if len(last_row) > 0 else ""
        col1 = last_row[1].strip() if len(last_row) > 1 else ""

        ctx_stack = ContextStack()
        if col0:
            ctx_stack.update(level=1, numbering=col0, title="", col_idx=0)
        if col1:
            ctx_stack.update(level=2, numbering="", title=col1, col_idx=1)

        path = ctx_stack.get_full_path(headers)

        return RowContext(
            row_id=col0,
            title=col1,
            level=2 if col1 else 1,
            path=path,
            stack=ctx_stack
        )

    @staticmethod
    def apply_context_to_rows(rows: List[List[str]], active_context: RowContext, expected_cols: int = 3) -> List[List[str]]:
        if not active_context or active_context.is_empty() or not rows:
            return rows

        updated_rows = [list(r) for r in rows]

        for r_idx in range(len(updated_rows)):
            row = updated_rows[r_idx]
            col0 = row[0].strip() if len(row) > 0 else ""
            col1 = row[1].strip() if len(row) > 1 else ""

            # If a row introduces a NEW section/numbering ID (e.g. "3.2", "4.1") different from active_context, stop
            if col0 and active_context.row_id and col0 != active_context.row_id and re.match(r"^(\d+(\.\d+)*|[A-ZIVX]+\.|\bMỤC\b|\bPHẦN\b)", col0, re.IGNORECASE):
                break

            # Fill active context into empty Col 0 and Col 1
            if len(row) > 0 and not col0 and active_context.row_id:
                row[0] = active_context.row_id
            if len(row) > 1 and not col1 and active_context.title:
                row[1] = active_context.title

        return updated_rows
