import fitz  # PyMuPDF
import base64
import io
import json
import requests
from typing import Tuple
from PIL import Image
from .base import BaseExtractor, TableData
from ..config import settings
import logging

logger = logging.getLogger(__name__)

class LLMVisionExtractor(BaseExtractor):
    def extract(self, pdf_path: str, page_num: int, bbox: Tuple[float, float, float, float]) -> TableData:
        try:
            doc = fitz.open(pdf_path)
            page = doc[page_num]
            rect = fitz.Rect(bbox)

            # Render page crop at 2.0 zoom for crisp vision resolution
            pix = page.get_pixmap(clip=rect, dpi=200)
            img_bytes = pix.tobytes("png")
            base64_img = base64.b64encode(img_bytes).decode("utf-8")

            prompt = (
                "You are an expert OCR table parser specializing in Vietnamese insurance and financial documents.\n"
                "Extract all tabular data from this image into a clean JSON structure.\n\n"
                "RULES FOR EXTRACTION:\n"
                "1. HEADERS: If table has multi-row headers, merge them into a single list of concise column headers.\n"
                "2. VERTICAL MERGED CELLS: If a cell spans vertically across multiple rows (e.g. general terms/paragraphs), place the text ONCE in the first row's cell and leave it empty in subsequent rows. DO NOT repeat the paragraph in every row.\n"
                "3. NESTED SUB-TABLES: If a cell contains a nested table (e.g. 'Nhóm chức danh | HMTC'), format the cell content cleanly as concise key-value pairs (e.g. 'Nhóm I: 1.000, Nhóm II: 700, Nhóm III: 200').\n"
                "4. OUTPUT FORMAT: Return ONLY a raw JSON object with keys 'headers' (list of strings) and 'rows' (list of string lists).\n"
                "Example: {\"headers\": [\"STT\", \"Tên mục\", \"Nội dung\"], \"rows\": [[\"3.3\", \"Điều kiện\", \"Nội dung 3.3\"], [\"3.4\", \"Phân nhóm\", \"Nội dung 3.4\"]]}\n"
            )

            payload = {
                "model": settings.OLLAMA_MODEL,
                "prompt": prompt,
                "images": [base64_img],
                "stream": False,
                "format": "json"
            }

            res = requests.post(
                f"{settings.OLLAMA_URL}/api/generate",
                json=payload,
                timeout=45
            )

            if res.status_code == 200:
                response_json = res.json()
                raw_response = response_json.get("response", "").strip()

                # Clean markdown blocks if any
                if raw_response.startswith("```"):
                    raw_response = raw_response.split("```")[1]
                    if raw_response.startswith("json"):
                        raw_response = raw_response[4:]

                parsed = json.loads(raw_response)
                headers = parsed.get("headers", [])
                rows = parsed.get("rows", [])

                return TableData(
                    headers=headers,
                    rows=rows,
                    confidence=0.9,
                    notes="LLM Vision extracted successfully"
                )

        except Exception as e:
            logger.warning(f"LLMVisionExtractor error on page {page_num}: {e}")

        return TableData(headers=[], rows=[], confidence=0.0, notes="LLM vision failed")
