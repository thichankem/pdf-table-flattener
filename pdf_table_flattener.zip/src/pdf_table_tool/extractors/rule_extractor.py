import pdfplumber
import re
from typing import Tuple, List
from .base import BaseExtractor, TableData
import logging

logger = logging.getLogger(__name__)

class RuleExtractor(BaseExtractor):
    def extract(self, pdf_path: str, page_num: int, bbox: Tuple[float, float, float, float]) -> TableData:
        try:
            with pdfplumber.open(pdf_path) as pdf:
                page = pdf.pages[page_num]
                # Crop to table bounding box with slight margin
                cropped = page.crop(bbox)
                extracted_table = cropped.extract_table({
                    "vertical_strategy": "lines",
                    "horizontal_strategy": "lines",
                    "snap_tolerance": 3,
                    "join_tolerance": 3,
                })

                if not extracted_table:
                    # Fallback strategy using text layout
                    extracted_table = cropped.extract_table({
                        "vertical_strategy": "text",
                        "horizontal_strategy": "text",
                    })

                if not extracted_table or len(extracted_table) == 0:
                    return TableData(headers=[], rows=[], confidence=0.0, notes="No grid extracted")

                # Clean cell text
                cleaned_rows = []
                for row in extracted_table:
                    cleaned_row = []
                    for cell in row:
                        val = cell.strip() if cell else ""
                        # Replace newlines inside cells with space
                        val = " ".join(val.split())
                        cleaned_row.append(val)
                    if any(cleaned_row):
                        cleaned_rows.append(cleaned_row)

                if not cleaned_rows:
                    return TableData(headers=[], rows=[], confidence=0.0, notes="All cells empty")

                # Deduplicate vertical rowspan text (generalized algorithm)
                cleaned_rows = self._deduplicate_vertical_spans(cleaned_rows)

                headers, data_rows = self._parse_headers_and_rows(cleaned_rows)

                # Assess confidence with repetition penalty
                non_empty_cells = sum(1 for r in cleaned_rows for c in r if c)
                total_cells = sum(len(r) for r in cleaned_rows)
                cell_fill_rate = non_empty_cells / total_cells if total_cells > 0 else 0

                # Check repetition penalty across rows for long text blocks
                rep_penalty = self._compute_repetition_penalty(cleaned_rows)

                # High confidence only if fill rate is good AND no severe text duplication
                if cell_fill_rate > 0.4 and headers and any(headers) and rep_penalty < 0.25:
                    confidence = 0.90
                else:
                    confidence = 0.40  # Trigger LLM fallback in Router

                return TableData(
                    headers=headers,
                    rows=data_rows,
                    confidence=confidence,
                    notes=f"Rule-based extracted {len(cleaned_rows)} rows (rep_penalty: {rep_penalty:.2f})"
                )
        except Exception as e:
            logger.error(f"RuleExtractor failed on page {page_num}: {e}")
            return TableData(headers=[], rows=[], confidence=0.0, notes=str(e))

    def _deduplicate_vertical_spans(self, rows: List[List[str]]) -> List[List[str]]:
        """
        Generalized Vertical Rowspan Deduplication:
        If a long text string (>30 chars) in column C appears identically in 2 or more
        consecutive rows, it's a merged cell. Keep it only in the first row.
        """
        if len(rows) <= 1:
            return rows

        num_cols = max(len(r) for r in rows)
        dedup_rows = [list(r) for r in rows]

        for col in range(num_cols):
            last_seen_text = ""
            for r_idx in range(len(dedup_rows)):
                if col < len(dedup_rows[r_idx]):
                    val = dedup_rows[r_idx][col].strip()
                    if len(val) > 30 and val == last_seen_text:
                        # Duplicate vertical span text detected! Clear in subsequent row
                        dedup_rows[r_idx][col] = ""
                    elif val:
                        # Check if val starts with last_seen_text (partially appended merged cell)
                        if last_seen_text and len(last_seen_text) > 30 and val.startswith(last_seen_text):
                            dedup_rows[r_idx][col] = val[len(last_seen_text):].strip()
                        else:
                            last_seen_text = val

        return dedup_rows

    def _compute_repetition_penalty(self, rows: List[List[str]]) -> float:
        """
        Computes text repetition penalty across rows.
        If many cells share identical long strings, returns a higher penalty score.
        """
        if len(rows) <= 1:
            return 0.0

        all_strings = []
        for r in rows:
            for c in r:
                val = c.strip()
                if len(val) > 20:
                    all_strings.append(val)

        if not all_strings:
            return 0.0

        total_count = len(all_strings)
        unique_count = len(set(all_strings))
        duplicate_ratio = (total_count - unique_count) / total_count
        return duplicate_ratio


    def _parse_headers_and_rows(self, cleaned_rows: List[List[str]]) -> Tuple[List[str], List[List[str]]]:
        if not cleaned_rows:
            return [], []

        # If Row 0 starts with bullet point or long paragraph text, there are NO header rows in this crop
        row0_str = " ".join([c for c in cleaned_rows[0] if c.strip()]).strip()
        if re.match(r"^[\+\-\*\•]\s", row0_str) or row0_str.startswith("- ") or row0_str.startswith("+ "):
            return [], cleaned_rows

        # Find first data row index
        data_start_idx = 1
        for i in range(1, min(4, len(cleaned_rows))):
            row = cleaned_rows[i]
            # Check if row looks like numeric/percentage data
            col0 = row[0].strip() if row else ""
            rest_cells = [c.strip() for c in row[1:] if c.strip()]
            
            # If col0 is a row index (digit, e.g. "1", "2") and rest cells are values (e.g. "0%", "90%"), it's a data row
            is_digit_col0 = col0.isdigit()
            is_data_values = any(re.search(r"\d+%", c) or c.isdigit() for c in rest_cells)

            if is_digit_col0 and is_data_values:
                data_start_idx = i
                break
            elif is_data_values and not any("bảo hiểm" in c.lower() or "thời hạn" in c.lower() for c in rest_cells[:2]):
                data_start_idx = i
                break

        header_rows = cleaned_rows[:data_start_idx]
        data_rows = cleaned_rows[data_start_idx:]

        if not header_rows:
            return [], cleaned_rows

        num_cols = max(len(r) for r in cleaned_rows)
        consolidated_headers = []

        for c in range(num_cols):
            col_header_vals = []
            for h_row in header_rows:
                if c < len(h_row) and h_row[c].strip():
                    val = h_row[c].strip()
                    if val not in col_header_vals:
                        col_header_vals.append(val)

            if not col_header_vals:
                consolidated_headers.append("")
            elif c == 0:
                # For Col 0, prefer the bottom-most non-generic header
                non_generic = [v for v in col_header_vals if "thời hạn bảo hiểm (" not in v.lower()]
                consolidated_headers.append(non_generic[-1] if non_generic else col_header_vals[-1])
            else:
                # For data columns, if one of header values is pure digit (e.g. '10', '15'), prefer it over long group titles
                digits = [v for v in col_header_vals if v.isdigit() or re.match(r"^\d+$", v.strip())]
                if digits:
                    consolidated_headers.append(digits[-1])
                else:
                    consolidated_headers.append(col_header_vals[-1])

        return consolidated_headers, data_rows
