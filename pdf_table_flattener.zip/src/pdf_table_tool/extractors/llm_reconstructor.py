import requests
import json
import logging
from typing import List, Dict, Any
from ..config import settings
from ..ollama_bootstrap import check_ollama_available

logger = logging.getLogger(__name__)

class LLMTableReconstructor:
    """
    Reconstructs corrupted, single-column, or borderless continuation table data
    into a fully structured N-column table using LLM (Ollama / Gemini).
    """

    @staticmethod
    def reconstruct_table(
        headers: List[str],
        rows: List[List[str]],
        active_context_path: List[str] = None
    ) -> List[List[str]]:
        if not rows or not headers or not check_ollama_available():
            return rows

        # Check if rows are single-column corrupted (all rows have len <= 1)
        is_corrupted = all(len([c for c in r if c.strip()]) <= 1 for r in rows)
        if not is_corrupted:
            return rows

        logger.info("LLMTableReconstructor: Single-column table corruption detected. Triggering LLM topology reconstruction.")

        raw_text_lines = []
        for r in rows:
            line = " ".join([c for c in r if c.strip()])
            if line:
                raw_text_lines.append(line)

        raw_text = "\n".join(raw_text_lines)
        context_info = " -> ".join(active_context_path) if active_context_path else "None"

        prompt = f"""You are a PDF Table Topology Repair Agent specializing in Vietnamese banking documents.
We extracted a table continuation that lost column grid boundaries.
Target Column Headers: {json.dumps(headers, ensure_ascii=False)}
Parent Context: {context_info}

Raw Text Content:
\"\"\"
{raw_text}
\"\"\"

INSTRUCTIONS:
1. Reconstruct the raw text lines into a JSON array of rows matching the {len(headers)} target headers.
2. For bullet items or continuation text (e.g. starting with '+', '-', or bullet points), place them in the LAST column ({headers[-1] if headers else 'Quy định'}).
3. Leave Column 0 and Column 1 empty if they are inherited from Parent Context (or fill with inherited values).
4. Return ONLY valid JSON format: {{"rows": [["col0_val", "col1_val", "col2_val"], ...]}}
"""

        try:
            payload = {
                "model": settings.OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False,
                "format": "json"
            }
            res = requests.post(
                f"{settings.OLLAMA_URL}/api/generate",
                json=payload,
                timeout=30
            )
            if res.status_code == 200:
                raw_resp = res.json().get("response", "").strip()
                parsed = json.loads(raw_resp)
                new_rows = parsed.get("rows", [])
                if new_rows and isinstance(new_rows, list):
                    logger.info(f"LLMTableReconstructor: Reconstructed {len(new_rows)} rows successfully.")
                    return new_rows
        except Exception as e:
            logger.warning(f"LLMTableReconstructor failed: {e}")

        return rows
