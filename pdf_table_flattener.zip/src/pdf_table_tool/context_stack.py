from dataclasses import dataclass, field
from typing import List, Optional, Any

@dataclass
class BBox:
    x0: float
    y0: float
    x1: float
    y1: float
    page: int = 0

@dataclass
class Cell:
    text: str
    bbox: Optional[BBox] = None
    rowspan: int = 1
    colspan: int = 1
    confidence: float = 1.0
    is_merged_fill: bool = False

@dataclass
class StackFrame:
    level: int           # Depth (1: Main Section, 2: SubSection, 3: Item)
    numbering: str       # e.g., "3.1"
    title: str           # e.g., "Điều kiện vay vốn"
    col_idx: int         # Source column index

    def to_path_segment(self, header_name: str = "") -> str:
        prefix = f"{header_name}: " if header_name else ""
        if self.numbering and self.title:
            return f"{prefix}{self.numbering} - {self.title}"
        elif self.numbering:
            return f"{prefix}{self.numbering}"
        return f"{prefix}{self.title}"

class ContextStack:
    """
    Manages multi-level hierarchical row context (Stack-based propagation).
    Replaces single-level ActiveMergedRow.
    """

    def __init__(self):
        self.stack: List[StackFrame] = []

    def update(self, level: int, numbering: str, title: str, col_idx: int):
        """
        Updates stack hierarchy. When a new header at level `level` arrives,
        pops all frames with depth >= `level`, then pushes the new frame.
        """
        self.stack = [f for f in self.stack if f.level < level]
        if numbering or title:
            self.stack.append(StackFrame(level=level, numbering=numbering.strip(), title=title.strip(), col_idx=col_idx))

    def get_full_path(self, headers: List[str] = None) -> List[str]:
        path = []
        for frame in self.stack:
            header_name = ""
            if headers and 0 <= frame.col_idx < len(headers):
                header_name = headers[frame.col_idx]
            path.append(frame.to_path_segment(header_name))
        return path

    def is_empty(self) -> bool:
        return len(self.stack) == 0

    def copy(self) -> "ContextStack":
        new_cs = ContextStack()
        new_cs.stack = list(self.stack)
        return new_cs

    def clear(self):
        self.stack.clear()
