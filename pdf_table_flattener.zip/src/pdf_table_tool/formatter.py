import re
from typing import List
from .extractors.base import TableData
import logging

logger = logging.getLogger(__name__)

class TableFormatter:
    @staticmethod
    def format_to_bullets(table_data: TableData) -> List[str]:
        """
        Formats extracted TableData into clean, hierarchical bullet points (Cell AST rendering).
        If cell content contains multi-line bullets or sub-bullets (+ under -),
        prints the row header once and indents nested sub-bullets underneath.
        """
        headers = table_data.headers or []
        rows = table_data.rows or []

        # Filter out fake headers like 'Cột 1', 'Column 1', 'Unnamed: 0', etc.
        cleaned_headers = []
        for h in headers:
            h_str = str(h).strip() if h else ""
            if re.match(r"^(cột|column|stt|no\.?)\s*\d+$", h_str, re.IGNORECASE) or h_str.lower().startswith("unnamed"):
                cleaned_headers.append("")
            else:
                cleaned_headers.append(h_str)

        bullet_lines = []

        is_continuation_table = getattr(table_data, "is_continuation", False)

        for row_idx, row in enumerate(rows):
            if not any(row):
                continue

            # Separate header-level context (col 0, col 1) from detail content (col 2)
            header_pairs = []
            detail_cell = ""
            detail_header = ""

            for col_idx, cell in enumerate(row):
                val = str(cell).strip() if cell else ""
                if not val:
                    continue

                header = cleaned_headers[col_idx] if col_idx < len(cleaned_headers) else ""
                
                # Check if this cell is multi-line or contains nested bullets (+ or -)
                is_multiline_detail = (col_idx == len(row) - 1) and ("\n" in val or bool(re.search(r"[\+\-\*\•]\s", val)))

                if is_multiline_detail:
                    detail_cell = val
                    detail_header = header
                else:
                    val_clean = re.sub(r"\s+", " ", val)
                    if header and not TableFormatter._should_skip_header(header, val_clean, col_idx):
                        h_str = re.sub(r":\s*$", "", header)
                        v_str = re.sub(r"^:\s*", "", val_clean)
                        header_pairs.append(f"{h_str}: {v_str}")
                    else:
                        header_pairs.append(val_clean)

            # Case 1: Row has header pairs AND multi-line detail cell
            if header_pairs and detail_cell:
                # Omit repeating parent header on continuation pages for row 0
                is_inherited = is_continuation_table and (row_idx == 0)
                if not is_inherited:
                    header_line = "  |  ".join(header_pairs)
                    header_line = re.sub(r":\s*:\s*", ": ", header_line)
                    header_line = re.sub(r":\s*-\s*", " - ", header_line)
                    if not (header_line.startswith("- ") or header_line.startswith("+ ")):
                        header_line = f"- {header_line}"
                    bullet_lines.append(header_line)

                # Format detail_cell lines as indented AST bullets
                detail_lines = TableFormatter._format_detail_ast(detail_cell, detail_header)
                bullet_lines.extend(detail_lines)

            # Case 2: Standard single-line or combined row formatting
            else:
                pairs = []
                for col_idx, cell in enumerate(row):
                    val = str(cell).strip() if cell else ""
                    if not val:
                        continue
                    val_clean = re.sub(r"\s+", " ", val)
                    header = cleaned_headers[col_idx] if col_idx < len(cleaned_headers) else ""

                    if header and not TableFormatter._should_skip_header(header, val_clean, col_idx):
                        h_str = re.sub(r":\s*$", "", header)
                        v_str = re.sub(r"^:\s*", "", val_clean)
                        pairs.append(f"{h_str}: {v_str}")
                    else:
                        pairs.append(val_clean)

                if pairs:
                    line_content = "  |  ".join(pairs)
                    line_content = re.sub(r":\s*:\s*", ": ", line_content)
                    line_content = re.sub(r":\s*-\s*", " - ", line_content)
                    if line_content.startswith("- ") or line_content.startswith("+ "):
                        bullet_lines.append(line_content)
                    else:
                        bullet_lines.append(f"- {line_content}")

        if not bullet_lines and headers:
            clean_headers_vals = [re.sub(r"\s+", " ", h) for h in headers if h and str(h).strip()]
            if clean_headers_vals:
                bullet_lines.append(f"- {'  |  '.join(clean_headers_vals)}")

        return bullet_lines

    @staticmethod
    def _format_detail_ast(detail_text: str, detail_header: str = "") -> List[str]:
        """
        Parses cell text buffer into a nested AST bullet structure:
        - Level 1 bullets (- ): indented 2 spaces
        - Level 2 bullets (+ ): indented 4 spaces
        - Continuation paragraphs: indented under parent bullet
        """
        lines = detail_text.split("\n")
        formatted = []

        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue

            # Sub-bullet (Level 2): starts with '+'
            if line_str.startswith("+ ") or line_str.startswith("+"):
                item = re.sub(r"^\+\s*", "", line_str)
                formatted.append(f"    + {item}")
            # Main bullet (Level 1): starts with '-' or '*' or '•'
            elif re.match(r"^[\-\*\•]\s*", line_str):
                item = re.sub(r"^[\-\*\•]\s*", "", line_str)
                formatted.append(f"  - {item}")
            # Continuation paragraph text under active bullet
            else:
                formatted.append(f"    {line_str}")

        return formatted

    @staticmethod
    def _should_skip_header(header: str, val: str, col_idx: int = -1) -> bool:
        h_clean = header.strip().lower()
        v_clean = val.strip().lower()
        if not h_clean:
            return True
        if re.match(r"^[\+\-\*\•]\s", h_clean):
            return True
        if h_clean == v_clean:
            return True
        if v_clean.startswith(f"{h_clean}:") or v_clean.startswith(f"{h_clean} :"):
            return True
        if col_idx == 0 and len(v_clean) > len(h_clean) and h_clean in v_clean:
            return True
        if h_clean.isdigit() or re.match(r"^\d+\s*%", h_clean):
            return False
        return False
